Source: https://github.com/lennney/stop-that-shit
Release: 0.2.5
Commit: 8bc1ac558167121e7f28d9fb0bec05c039952206
Installed component: advisory Skill only (no Guard hooks).
License: MIT; see LICENSE.
