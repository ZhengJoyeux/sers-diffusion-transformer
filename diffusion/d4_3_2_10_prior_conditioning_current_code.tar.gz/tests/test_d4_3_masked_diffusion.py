from __future__ import annotations

import numpy as np
import torch

from src.conditional_diversity_constraints import (
    fit_condition_aware_diversity_constraint_state,
)
from src.model_builder import build_diffusion_model


def _configuration() -> dict:
    return {
        "data": {"raman_axis_mode": "union_with_valid_mask"},
        "conditioning": {
            "enabled": True,
            "vector_size": 14,
            "embedding_dimension": 8,
            "injection": "input_and_all_resnet_blocks_film",
        },
        "normalization": {"enabled": True},
        "prior_residual": {"enabled": False},
        "broad_local_residual": {"enabled": False},
        "physics_constraints": {"enabled": False},
        "diversity_constraints": {
            "enabled": True,
            "total_weight": 0.02,
            "maximum_total_ratio_to_ddpm": 0.02,
            "condition_grouping": {
                "samples_per_condition": 4,
                "shared_timestep": True,
            },
            "low_noise_gate": {
                "minimum_alpha_cumprod": 0.5,
                "minimum_samples": 4,
            },
            "pairwise_distance": {
                "minimum_distance_ratio": 0.8,
                "maximum_distance_ratio": 1.25,
            },
            "pointwise_variance_floor": {
                "minimum_std_ratio": 0.8,
                "maximum_std_ratio": 1.25,
            },
            "peak_morphology": {"enabled": False},
        },
        "local_peak_distribution_constraints": {"enabled": False},
        "peak_derivative_constraints": {"enabled": False},
        "relative_peak_intensity_constraints": {"enabled": False},
        "peak_parameter_constraints": {"enabled": False},
        "model": {
            "channels": 1,
            "base_dimension": 8,
            "dimension_multipliers": [1, 2],
            "self_condition": False,
            "dropout": 0.0,
        },
        "diffusion": {
            "diffusion_timesteps": 10,
            "sampling_timesteps": 2,
            "objective": "pred_x0",
            "beta_schedule": "cosine",
            "ddim_sampling_eta": 0.0,
            "auto_normalize": False,
            "loss_weighting": "uniform",
            "residual_aware_loss": {"enabled": False},
        },
    }


def test_d4_3_runs_inside_masked_diffusion_without_state_dict_changes() -> None:
    generator = np.random.default_rng(2026)
    training = generator.normal(0.0, 0.1, size=(8, 16)).astype(np.float32)
    masks = np.ones_like(training)
    conditions = np.zeros((8, 14), dtype=np.float32)
    conditions[:, 0] = 1.0
    state = fit_condition_aware_diversity_constraint_state(
        training_scaled_residuals=training,
        training_valid_masks=masks,
        training_condition_vectors=conditions,
        configuration=_configuration()["diversity_constraints"],
    )

    _, diffusion = build_diffusion_model(_configuration(), sequence_length=16)
    keys_before = set(diffusion.state_dict())
    diffusion.configure_diversity_constraints(
        diversity_constraint_state=state
    )
    keys_after = set(diffusion.state_dict())
    assert keys_before == keys_after

    spectrum = torch.as_tensor(training[:4]).unsqueeze(1)
    mask = torch.ones_like(spectrum)
    condition = torch.as_tensor(conditions[:4])
    loss = diffusion.p_losses(
        spectrum,
        torch.zeros(4, dtype=torch.long),
        noise=torch.zeros_like(spectrum),
        valid_mask=mask,
        condition=condition,
    )
    assert torch.isfinite(loss)
    loss.backward()
    assert any(
        parameter.grad is not None and torch.isfinite(parameter.grad).all()
        for parameter in diffusion.parameters()
    )
    components = diffusion.get_latest_loss_components()
    assert components["conditional_diversity_active_groups"] == 1
    assert components["diversity_loss"] <= 0.02 * components["ddpm_loss"] + 1.0e-8


def test_conditioned_model_predictions_supports_explicit_diagnostic_context() -> None:
    _, diffusion = build_diffusion_model(_configuration(), sequence_length=16)
    spectrum = torch.randn(1, 1, 16)
    timestep = torch.tensor([9], dtype=torch.long)
    mask = torch.ones_like(spectrum)
    mask[..., 12:] = 0.0
    condition = torch.zeros(1, 14)
    condition[:, 0] = 1.0

    prediction = diffusion.model_predictions(
        spectrum,
        timestep,
        clip_x_start=False,
        valid_mask=mask,
        condition=condition,
    )

    assert prediction.pred_x_start.shape == spectrum.shape
    assert prediction.pred_noise.shape == spectrum.shape
    assert torch.all(prediction.pred_x_start[..., 12:] == 0.0)
    assert torch.all(prediction.pred_noise[..., 12:] == 0.0)
