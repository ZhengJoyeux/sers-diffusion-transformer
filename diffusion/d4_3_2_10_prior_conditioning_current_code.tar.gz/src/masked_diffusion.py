"""具有逐样本Raman有效区掩码的一维高斯扩散。"""

from __future__ import annotations

from collections import namedtuple
from random import random
from typing import Any

import torch
from torch.nn import functional as F

from src.one_dimensional_ddpm import GaussianDiffusion1D
from src.conditional_diversity_constraints import (
    DifferentiableConditionAwareDiversityLoss,
    normalize_condition_aware_diversity_configuration,
)


MaskedModelPrediction = namedtuple(
    "MaskedModelPrediction",
    ["pred_noise", "pred_x_start"],
)


def _extract(
    values: torch.Tensor,
    timesteps: torch.Tensor,
    target_shape: torch.Size,
) -> torch.Tensor:
    gathered = values.gather(-1, timesteps)
    return gathered.reshape(
        timesteps.shape[0],
        *((1,) * (len(target_shape) - 1)),
    )


def _normalize_quality_fidelity_configuration(
    diversity_configuration: dict[str, Any],
) -> dict[str, Any]:
    """Validate the optional D4.3.2 fidelity block.

    It deliberately lives below ``diversity_constraints`` so the existing
    model-builder call remains checkpoint-compatible: no new constructor
    argument or public interface is required.
    """

    source = diversity_configuration.get("quality_fidelity", {}) or {}
    if not isinstance(source, dict):
        raise ValueError("quality_fidelity必须是字典。")
    enabled = bool(source.get("enabled", False))
    normalized: dict[str, Any] = {
        "enabled": enabled,
        "total_weight": float(source.get("total_weight", 0.0)),
        "maximum_total_ratio_to_ddpm": float(
            source.get("maximum_total_ratio_to_ddpm", 0.0)
        ),
    }
    if not enabled:
        return normalized
    if normalized["total_weight"] <= 0.0:
        raise ValueError("quality_fidelity.total_weight必须大于0。")
    if not 0.0 < normalized["maximum_total_ratio_to_ddpm"] <= 0.25:
        raise ValueError(
            "quality_fidelity.maximum_total_ratio_to_ddpm必须位于(0,0.25]。"
        )

    high_noise_sampling = source.get("high_noise_sampling", {}) or {}
    high_noise = source.get("high_noise_weighting", {}) or {}
    derivative = source.get("first_derivative", {}) or {}
    multiscale = source.get("multiscale_shape", {}) or {}
    multiscale_variance = source.get(
        "condition_multiscale_variance_floor", {}
    ) or {}
    derivative_variance = source.get(
        "condition_derivative_variance_floor", {}
    ) or {}
    condition_mean = source.get("condition_mean", {}) or {}
    envelope = source.get("condition_pointwise_envelope", {}) or {}
    if not all(
        isinstance(item, dict)
        for item in (
            high_noise_sampling,
            high_noise,
            derivative,
            multiscale,
            multiscale_variance,
            derivative_variance,
            condition_mean,
            envelope,
        )
    ):
        raise ValueError("quality_fidelity的子配置必须是字典。")

    normalized["high_noise_sampling"] = {
        "enabled": bool(high_noise_sampling.get("enabled", False)),
        "sampling_probability": float(
            high_noise_sampling.get("sampling_probability", 0.0)
        ),
        "minimum_timestep_fraction": float(
            high_noise_sampling.get("minimum_timestep_fraction", 0.75)
        ),
    }
    high_sampling = normalized["high_noise_sampling"]
    if high_sampling["enabled"] and not (
        0.0 < high_sampling["sampling_probability"] <= 0.75
        and 0.50 <= high_sampling["minimum_timestep_fraction"] < 1.0
    ):
        raise ValueError(
            "high_noise_sampling要求sampling_probability位于(0,0.75]且"
            "minimum_timestep_fraction位于[0.5,1)。"
        )

    normalized["high_noise_weighting"] = {
        "enabled": bool(high_noise.get("enabled", False)),
        "maximum_weight": float(high_noise.get("maximum_weight", 1.0)),
        "power": float(high_noise.get("power", 1.0)),
    }
    high = normalized["high_noise_weighting"]
    if high["enabled"] and (
        not 1.0 <= high["maximum_weight"] <= 4.0 or high["power"] <= 0.0
    ):
        raise ValueError("high_noise_weighting要求maximum_weight位于[1,4]且power>0。")

    normalized["first_derivative"] = {
        "enabled": bool(derivative.get("enabled", False)),
        "smooth_l1_beta": float(derivative.get("smooth_l1_beta", 0.05)),
        "weight": float(derivative.get("weight", 1.0)),
    }
    first = normalized["first_derivative"]
    if first["enabled"] and (
        first["smooth_l1_beta"] <= 0.0 or first["weight"] <= 0.0
    ):
        raise ValueError("first_derivative要求smooth_l1_beta和weight均大于0。")

    kernel_sizes = [int(value) for value in multiscale.get("kernel_sizes", [])]
    normalized["multiscale_shape"] = {
        "enabled": bool(multiscale.get("enabled", False)),
        "kernel_sizes": kernel_sizes,
        "smooth_l1_beta": float(multiscale.get("smooth_l1_beta", 0.05)),
        "weight": float(multiscale.get("weight", 1.0)),
    }
    multi = normalized["multiscale_shape"]
    if multi["enabled"] and (
        not kernel_sizes
        or any(value < 3 or value % 2 == 0 or value > 127 for value in kernel_sizes)
        or len(set(kernel_sizes)) != len(kernel_sizes)
        or multi["smooth_l1_beta"] <= 0.0
        or multi["weight"] <= 0.0
    ):
        raise ValueError(
            "multiscale_shape要求互不重复的奇数kernel_sizes位于[3,127]，"
            "且smooth_l1_beta和weight均大于0。"
        )

    variance_kernel_sizes = [
        int(value) for value in multiscale_variance.get("kernel_sizes", [])
    ]
    normalized["condition_multiscale_variance_floor"] = {
        "enabled": bool(multiscale_variance.get("enabled", False)),
        "kernel_sizes": variance_kernel_sizes,
        "minimum_group_size": int(
            multiscale_variance.get("minimum_group_size", 4)
        ),
        "minimum_std_ratio": float(
            multiscale_variance.get("minimum_std_ratio", 0.85)
        ),
        "active_std_quantile": float(
            multiscale_variance.get("active_std_quantile", 20.0)
        ),
        "maximum_timestep_fraction": float(
            multiscale_variance.get("maximum_timestep_fraction", 0.50)
        ),
        "smooth_l1_beta": float(
            multiscale_variance.get("smooth_l1_beta", 0.05)
        ),
        "weight": float(multiscale_variance.get("weight", 1.0)),
    }
    variance_floor = normalized["condition_multiscale_variance_floor"]
    if variance_floor["enabled"] and (
        not variance_kernel_sizes
        or any(
            value < 3 or value % 2 == 0 or value > 127
            for value in variance_kernel_sizes
        )
        or len(set(variance_kernel_sizes)) != len(variance_kernel_sizes)
        or variance_floor["minimum_group_size"] < 3
        or not 0.0 < variance_floor["minimum_std_ratio"] <= 1.0
        or not 0.0 <= variance_floor["active_std_quantile"] <= 80.0
        or not 0.0 < variance_floor["maximum_timestep_fraction"] <= 1.0
        or variance_floor["smooth_l1_beta"] <= 0.0
        or variance_floor["weight"] <= 0.0
    ):
        raise ValueError("condition_multiscale_variance_floor配置无效。")

    derivative_kernel_sizes = [
        int(value)
        for value in derivative_variance.get("smoothing_kernel_sizes", [])
    ]
    normalized["condition_derivative_variance_floor"] = {
        "enabled": bool(derivative_variance.get("enabled", False)),
        "smoothing_kernel_sizes": derivative_kernel_sizes,
        "minimum_group_size": int(
            derivative_variance.get("minimum_group_size", 4)
        ),
        "minimum_std_ratio": float(
            derivative_variance.get("minimum_std_ratio", 0.90)
        ),
        "active_std_quantile": float(
            derivative_variance.get("active_std_quantile", 30.0)
        ),
        "maximum_timestep_fraction": float(
            derivative_variance.get("maximum_timestep_fraction", 0.50)
        ),
        "smooth_l1_beta": float(
            derivative_variance.get("smooth_l1_beta", 0.05)
        ),
        "weight": float(derivative_variance.get("weight", 1.0)),
    }
    derivative_floor = normalized["condition_derivative_variance_floor"]
    if derivative_floor["enabled"] and (
        not derivative_kernel_sizes
        or any(
            value < 3 or value % 2 == 0 or value > 127
            for value in derivative_kernel_sizes
        )
        or len(set(derivative_kernel_sizes)) != len(derivative_kernel_sizes)
        or derivative_floor["minimum_group_size"] < 3
        or not 0.0 < derivative_floor["minimum_std_ratio"] <= 1.0
        or not 0.0 <= derivative_floor["active_std_quantile"] <= 80.0
        or not 0.0 < derivative_floor["maximum_timestep_fraction"] <= 1.0
        or derivative_floor["smooth_l1_beta"] <= 0.0
        or derivative_floor["weight"] <= 0.0
    ):
        raise ValueError("condition_derivative_variance_floor配置无效。")

    normalized["condition_mean"] = {
        "enabled": bool(condition_mean.get("enabled", False)),
        "smooth_l1_beta": float(condition_mean.get("smooth_l1_beta", 0.05)),
        "minimum_group_size": int(condition_mean.get("minimum_group_size", 4)),
        "weight": float(condition_mean.get("weight", 1.0)),
    }
    mean = normalized["condition_mean"]
    if mean["enabled"] and (
        mean["smooth_l1_beta"] <= 0.0
        or mean["minimum_group_size"] < 2
        or mean["weight"] <= 0.0
    ):
        raise ValueError(
            "condition_mean要求smooth_l1_beta和weight大于0且"
            "minimum_group_size至少为2。"
        )

    normalized["condition_pointwise_envelope"] = {
        "enabled": bool(envelope.get("enabled", False)),
        "lower_quantile": float(envelope.get("lower_quantile", 0.05)),
        "upper_quantile": float(envelope.get("upper_quantile", 0.95)),
        "iqr_margin": float(envelope.get("iqr_margin", 0.75)),
        "smooth_l1_beta": float(envelope.get("smooth_l1_beta", 0.05)),
        "minimum_group_size": int(envelope.get("minimum_group_size", 4)),
        "weight": float(envelope.get("weight", 1.0)),
    }
    bounds = normalized["condition_pointwise_envelope"]
    if bounds["enabled"] and not (
        0.0 <= bounds["lower_quantile"] < 0.25
        and 0.75 < bounds["upper_quantile"] <= 1.0
        and bounds["lower_quantile"] < bounds["upper_quantile"]
        and bounds["iqr_margin"] >= 0.0
        and bounds["smooth_l1_beta"] > 0.0
        and bounds["minimum_group_size"] >= 2
        and bounds["weight"] > 0.0
    ):
        raise ValueError("condition_pointwise_envelope配置无效。")
    if not any(
        (
            first["enabled"],
            multi["enabled"],
            variance_floor["enabled"],
            derivative_floor["enabled"],
            mean["enabled"],
            bounds["enabled"],
        )
    ):
        raise ValueError("quality_fidelity至少需要启用一个保真损失。")
    return normalized


class MaskedGaussianDiffusion1D(GaussianDiffusion1D):
    """只在真实测量的Raman点上加噪、计算损失和采样。"""

    supports_valid_mask = True
    supports_condition = True

    def __init__(
        self,
        *args,
        diversity_configuration: dict[str, Any] | None = None,
        **kwargs,
    ) -> None:
        if bool(kwargs.get("auto_normalize", True)):
            raise ValueError(
                "掩码扩散要求diffusion.auto_normalize=false，"
                "并使用项目的train-only归一化。"
            )
        super().__init__(*args, **kwargs)
        self._sampling_valid_mask: torch.Tensor | None = None
        self._sampling_condition: torch.Tensor | None = None
        self._latest_loss_components: dict[str, torch.Tensor] = {}
        self.diversity_configuration = (
            normalize_condition_aware_diversity_configuration(
                diversity_configuration or {"enabled": False}
            )
        )
        self.diversity_enabled = bool(
            self.diversity_configuration.get("enabled", False)
        )
        self.diversity_total_weight = (
            float(self.diversity_configuration["total_weight"])
            if self.diversity_enabled
            else 0.0
        )
        self.diversity_maximum_ratio = (
            float(
                self.diversity_configuration[
                    "maximum_total_ratio_to_ddpm"
                ]
            )
            if self.diversity_enabled
            else 0.0
        )
        self.diversity_loss_module: (
            DifferentiableConditionAwareDiversityLoss | None
        ) = None
        self.quality_fidelity_configuration = (
            _normalize_quality_fidelity_configuration(
                diversity_configuration or {"enabled": False}
            )
        )
        self.quality_fidelity_enabled = bool(
            self.quality_fidelity_configuration.get("enabled", False)
        )
        if self.quality_fidelity_enabled and self.objective != "pred_x0":
            raise ValueError("D4.3.2 quality_fidelity当前只支持objective=pred_x0。")

    def _high_noise_weights(self, timesteps: torch.Tensor) -> torch.Tensor:
        configuration = self.quality_fidelity_configuration.get(
            "high_noise_weighting", {}
        )
        if not self.quality_fidelity_enabled or not bool(
            configuration.get("enabled", False)
        ):
            return torch.ones_like(timesteps, dtype=torch.float32)
        denominator = float(max(self.num_timesteps - 1, 1))
        fraction = timesteps.to(dtype=torch.float32) / denominator
        maximum = float(configuration["maximum_weight"])
        power = float(configuration["power"])
        return 1.0 + (maximum - 1.0) * fraction.pow(power)

    def _sample_training_timesteps(
        self,
        count: int,
        device: torch.device,
    ) -> torch.Tensor:
        """Sample all noise levels while reserving coverage for the hard tail."""

        number = int(count)
        if number <= 0:
            raise ValueError("训练时间步抽样数量必须大于0。")
        uniform = torch.randint(
            0,
            self.num_timesteps,
            (number,),
            device=device,
        ).long()
        configuration = self.quality_fidelity_configuration.get(
            "high_noise_sampling", {}
        )
        if not self.quality_fidelity_enabled or not bool(
            configuration.get("enabled", False)
        ):
            return uniform

        probability = float(configuration["sampling_probability"])
        minimum_fraction = float(configuration["minimum_timestep_fraction"])
        high_start = min(
            max(int(round(minimum_fraction * (self.num_timesteps - 1))), 0),
            self.num_timesteps - 1,
        )
        high = torch.randint(
            high_start,
            self.num_timesteps,
            (number,),
            device=device,
        ).long()
        choose_high = torch.rand(number, device=device) < probability
        return torch.where(choose_high, high, uniform)

    @staticmethod
    def _masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        count = mask.sum().clamp_min(1.0)
        return (value * mask).sum() / count

    def _quality_fidelity_losses(
        self,
        *,
        prediction: torch.Tensor,
        target: torch.Tensor,
        valid_mask: torch.Tensor,
        condition: torch.Tensor,
        timesteps: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        zero = prediction.sum() * 0.0
        derivative_loss = zero
        multiscale_loss = zero
        multiscale_variance_loss = zero
        derivative_variance_loss = zero
        condition_mean_loss = zero
        envelope_loss = zero
        active_groups = zero

        derivative = self.quality_fidelity_configuration.get(
            "first_derivative", {}
        )
        if bool(derivative.get("enabled", False)):
            derivative_mask = valid_mask[..., 1:] * valid_mask[..., :-1]
            predicted_derivative = prediction[..., 1:] - prediction[..., :-1]
            target_derivative = target[..., 1:] - target[..., :-1]
            pointwise = F.smooth_l1_loss(
                predicted_derivative,
                target_derivative,
                reduction="none",
                beta=float(derivative["smooth_l1_beta"]),
            )
            derivative_loss = self._masked_mean(pointwise, derivative_mask)

        multiscale = self.quality_fidelity_configuration.get(
            "multiscale_shape", {}
        )
        if bool(multiscale.get("enabled", False)):
            scale_losses: list[torch.Tensor] = []
            for kernel_size in multiscale["kernel_sizes"]:
                padding = int(kernel_size) // 2
                pooled_mask = F.avg_pool1d(
                    valid_mask,
                    kernel_size=int(kernel_size),
                    stride=1,
                    padding=padding,
                    count_include_pad=True,
                )
                predicted_pool = F.avg_pool1d(
                    prediction * valid_mask,
                    kernel_size=int(kernel_size),
                    stride=1,
                    padding=padding,
                    count_include_pad=True,
                ) / pooled_mask.clamp_min(1.0e-12)
                target_pool = F.avg_pool1d(
                    target * valid_mask,
                    kernel_size=int(kernel_size),
                    stride=1,
                    padding=padding,
                    count_include_pad=True,
                ) / pooled_mask.clamp_min(1.0e-12)
                pointwise = F.smooth_l1_loss(
                    predicted_pool,
                    target_pool,
                    reduction="none",
                    beta=float(multiscale["smooth_l1_beta"]),
                )
                pooled_valid = (pooled_mask > 1.0e-12).to(pointwise.dtype)
                scale_losses.append(self._masked_mean(pointwise, pooled_valid))
            if scale_losses:
                multiscale_loss = torch.stack(scale_losses).mean()

        condition_mean = self.quality_fidelity_configuration.get(
            "condition_mean", {}
        )
        envelope = self.quality_fidelity_configuration.get(
            "condition_pointwise_envelope", {}
        )
        variance_floor = self.quality_fidelity_configuration.get(
            "condition_multiscale_variance_floor", {}
        )
        derivative_floor = self.quality_fidelity_configuration.get(
            "condition_derivative_variance_floor", {}
        )
        needs_condition_groups = bool(condition_mean.get("enabled", False)) or bool(
            envelope.get("enabled", False)
        ) or bool(variance_floor.get("enabled", False))
        needs_condition_groups = needs_condition_groups or bool(
            derivative_floor.get("enabled", False)
        )
        if needs_condition_groups:
            _, inverse = torch.unique(
                condition.detach(), dim=0, sorted=True, return_inverse=True
            )
            mean_group_losses: list[torch.Tensor] = []
            envelope_group_losses: list[torch.Tensor] = []
            variance_group_losses: list[torch.Tensor] = []
            derivative_variance_group_losses: list[torch.Tensor] = []
            active_group_count = 0
            for group_index in range(int(inverse.max().item()) + 1):
                selected = inverse == group_index
                selected_count = int(selected.sum().item())
                group_target = target[selected]
                group_prediction = prediction[selected]
                group_mask = valid_mask[selected]
                group_valid = torch.min(
                    group_mask, dim=0, keepdim=True
                ).values
                group_is_active = False
                timestep_is_active = True
                if timesteps is not None:
                    timestep_is_active = bool(
                        (
                            timesteps[selected].to(dtype=torch.float32).mean()
                            / float(max(self.num_timesteps - 1, 1))
                        ).item()
                        <= float(
                            variance_floor.get("maximum_timestep_fraction", 1.0)
                        )
                    )

                if (
                    bool(variance_floor.get("enabled", False))
                    and selected_count
                    >= int(variance_floor["minimum_group_size"])
                    and timestep_is_active
                ):
                    kernel_losses: list[torch.Tensor] = []
                    for kernel_size in variance_floor["kernel_sizes"]:
                        padding = int(kernel_size) // 2
                        pooled_mask = F.avg_pool1d(
                            group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        )
                        predicted_pool = F.avg_pool1d(
                            group_prediction * group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        ) / pooled_mask.clamp_min(1.0e-12)
                        target_pool = F.avg_pool1d(
                            group_target * group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        ) / pooled_mask.clamp_min(1.0e-12)
                        predicted_std = torch.sqrt(
                            torch.mean(
                                torch.square(
                                    predicted_pool
                                    - predicted_pool.mean(dim=0, keepdim=True)
                                ),
                                dim=0,
                                keepdim=True,
                            ).clamp_min(1.0e-12)
                        )
                        target_std = torch.sqrt(
                            torch.mean(
                                torch.square(
                                    target_pool
                                    - target_pool.mean(dim=0, keepdim=True)
                                ),
                                dim=0,
                                keepdim=True,
                            ).clamp_min(1.0e-12)
                        ).detach()
                        valid_std = target_std[group_valid > 0.5]
                        active_threshold = torch.quantile(
                            valid_std,
                            float(variance_floor["active_std_quantile"]) / 100.0,
                        )
                        active_mask = group_valid * (
                            target_std >= active_threshold
                        ).to(group_valid.dtype)
                        minimum_std = (
                            float(variance_floor["minimum_std_ratio"])
                            * target_std
                        )
                        relative_deficit = F.relu(
                            minimum_std - predicted_std
                        ) / target_std.clamp_min(1.0e-6)
                        pointwise = F.smooth_l1_loss(
                            relative_deficit,
                            torch.zeros_like(relative_deficit),
                            reduction="none",
                            beta=float(variance_floor["smooth_l1_beta"]),
                        )
                        kernel_losses.append(
                            self._masked_mean(pointwise, active_mask)
                        )
                    if kernel_losses:
                        variance_group_losses.append(
                            torch.stack(kernel_losses).mean()
                        )
                        group_is_active = True

                derivative_timestep_is_active = True
                if timesteps is not None:
                    derivative_timestep_is_active = bool(
                        (
                            timesteps[selected].to(dtype=torch.float32).mean()
                            / float(max(self.num_timesteps - 1, 1))
                        ).item()
                        <= float(
                            derivative_floor.get(
                                "maximum_timestep_fraction", 1.0
                            )
                        )
                    )
                if (
                    bool(derivative_floor.get("enabled", False))
                    and selected_count
                    >= int(derivative_floor["minimum_group_size"])
                    and derivative_timestep_is_active
                ):
                    kernel_losses: list[torch.Tensor] = []
                    for kernel_size in derivative_floor[
                        "smoothing_kernel_sizes"
                    ]:
                        padding = int(kernel_size) // 2
                        pooled_mask = F.avg_pool1d(
                            group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        )
                        predicted_pool = F.avg_pool1d(
                            group_prediction * group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        ) / pooled_mask.clamp_min(1.0e-12)
                        target_pool = F.avg_pool1d(
                            group_target * group_mask,
                            kernel_size=int(kernel_size),
                            stride=1,
                            padding=padding,
                            count_include_pad=True,
                        ) / pooled_mask.clamp_min(1.0e-12)
                        predicted_derivative = (
                            predicted_pool[..., 1:] - predicted_pool[..., :-1]
                        )
                        target_derivative = (
                            target_pool[..., 1:] - target_pool[..., :-1]
                        )
                        predicted_std = torch.sqrt(torch.mean(torch.square(
                            predicted_derivative
                            - predicted_derivative.mean(dim=0, keepdim=True)
                        ), dim=0, keepdim=True).clamp_min(1.0e-12))
                        target_std = torch.sqrt(torch.mean(torch.square(
                            target_derivative
                            - target_derivative.mean(dim=0, keepdim=True)
                        ), dim=0, keepdim=True).clamp_min(1.0e-12)).detach()
                        full_window = (pooled_mask > 1.0 - 1.0e-6).to(
                            group_mask.dtype
                        )
                        derivative_valid = (
                            full_window[..., 1:] * full_window[..., :-1]
                        ).min(dim=0, keepdim=True).values
                        valid_std = target_std[derivative_valid > 0.5]
                        if valid_std.numel() == 0:
                            continue
                        active_threshold = torch.quantile(
                            valid_std,
                            float(derivative_floor["active_std_quantile"])
                            / 100.0,
                        )
                        active_mask = derivative_valid * (
                            target_std >= active_threshold
                        ).to(derivative_valid.dtype)
                        minimum_std = (
                            float(derivative_floor["minimum_std_ratio"])
                            * target_std
                        )
                        relative_deficit = F.relu(
                            minimum_std - predicted_std
                        ) / target_std.clamp_min(1.0e-6)
                        pointwise = F.smooth_l1_loss(
                            relative_deficit,
                            torch.zeros_like(relative_deficit),
                            reduction="none",
                            beta=float(derivative_floor["smooth_l1_beta"]),
                        )
                        kernel_losses.append(
                            self._masked_mean(pointwise, active_mask)
                        )
                    if kernel_losses:
                        derivative_variance_group_losses.append(
                            torch.stack(kernel_losses).mean()
                        )
                        group_is_active = True

                if bool(condition_mean.get("enabled", False)) and (
                    selected_count >= int(condition_mean["minimum_group_size"])
                ):
                    predicted_mean = group_prediction.mean(dim=0, keepdim=True)
                    target_mean = group_target.mean(dim=0, keepdim=True)
                    mean_pointwise = F.smooth_l1_loss(
                        predicted_mean,
                        target_mean,
                        reduction="none",
                        beta=float(condition_mean["smooth_l1_beta"]),
                    )
                    mean_group_losses.append(
                        self._masked_mean(mean_pointwise, group_valid)
                    )
                    group_is_active = True

                if bool(envelope.get("enabled", False)) and (
                    selected_count >= int(envelope["minimum_group_size"])
                ):
                    lower_q = torch.quantile(
                        group_target.detach(),
                        float(envelope["lower_quantile"]),
                        dim=0,
                        keepdim=True,
                    )
                    upper_q = torch.quantile(
                        group_target.detach(),
                        float(envelope["upper_quantile"]),
                        dim=0,
                        keepdim=True,
                    )
                    q25 = torch.quantile(
                        group_target.detach(), 0.25, dim=0, keepdim=True
                    )
                    q75 = torch.quantile(
                        group_target.detach(), 0.75, dim=0, keepdim=True
                    )
                    spread = (q75 - q25).clamp_min(0.0)
                    margin = float(envelope["iqr_margin"]) * spread
                    lower = lower_q - margin
                    upper = upper_q + margin
                    violation = F.relu(lower - group_prediction) + F.relu(
                        group_prediction - upper
                    )
                    envelope_pointwise = F.smooth_l1_loss(
                        violation,
                        torch.zeros_like(violation),
                        reduction="none",
                        beta=float(envelope["smooth_l1_beta"]),
                    )
                    envelope_group_losses.append(
                        self._masked_mean(envelope_pointwise, group_mask)
                    )
                    group_is_active = True
                active_group_count += int(group_is_active)

            if mean_group_losses:
                condition_mean_loss = torch.stack(mean_group_losses).mean()
            if envelope_group_losses:
                envelope_loss = torch.stack(envelope_group_losses).mean()
            if variance_group_losses:
                multiscale_variance_loss = torch.stack(
                    variance_group_losses
                ).mean()
            if derivative_variance_group_losses:
                derivative_variance_loss = torch.stack(
                    derivative_variance_group_losses
                ).mean()
            active_groups = prediction.new_tensor(float(active_group_count))

        raw = (
            float(derivative.get("weight", 0.0)) * derivative_loss
            + float(multiscale.get("weight", 0.0)) * multiscale_loss
            + float(variance_floor.get("weight", 0.0))
            * multiscale_variance_loss
            + float(derivative_floor.get("weight", 0.0))
            * derivative_variance_loss
            + float(condition_mean.get("weight", 0.0)) * condition_mean_loss
            + float(envelope.get("weight", 0.0)) * envelope_loss
        )
        return {
            "quality_fidelity_raw_loss": raw,
            "first_derivative_fidelity_loss": derivative_loss,
            "multiscale_shape_loss": multiscale_loss,
            "condition_multiscale_variance_floor_loss": multiscale_variance_loss,
            "condition_derivative_variance_floor_loss": derivative_variance_loss,
            "condition_mean_fidelity_loss": condition_mean_loss,
            "condition_envelope_loss": envelope_loss,
            "quality_fidelity_active_groups": active_groups,
        }

    def configure_diversity_constraints(
        self,
        *,
        diversity_constraint_state: dict[str, Any],
    ) -> None:
        if not self.diversity_enabled:
            return
        self.diversity_loss_module = DifferentiableConditionAwareDiversityLoss(
            diversity_constraint_state=diversity_constraint_state,
            padded_length=self.seq_length,
        )

    def get_latest_loss_components(self) -> dict[str, torch.Tensor]:
        return dict(self._latest_loss_components)

    def _prepare_condition(
        self,
        condition: torch.Tensor | None,
        batch_size: int,
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor | None:
        expected = int(getattr(self.model, "condition_dimension", 0))
        if expected == 0:
            if condition is not None:
                raise ValueError("无条件模型不能接收condition。")
            return None
        if condition is None:
            raise ValueError("D4.1条件模型必须提供condition。")
        if not torch.is_tensor(condition):
            raise TypeError("condition必须是torch.Tensor。")
        prepared = condition.to(device=device, dtype=dtype)
        if prepared.ndim == 1:
            prepared = prepared.unsqueeze(0)
        if prepared.shape[0] == 1 and batch_size > 1:
            prepared = prepared.expand(batch_size, -1)
        if prepared.shape != (batch_size, expected):
            raise ValueError(
                "condition形状必须为[B,C]："
                f"实际{tuple(prepared.shape)}，期望({batch_size}, {expected})。"
            )
        if not torch.isfinite(prepared).all():
            raise ValueError("condition包含NaN或无穷值。")
        return prepared

    def _prepare_mask(
        self,
        valid_mask: torch.Tensor | None,
        reference: torch.Tensor,
    ) -> torch.Tensor:
        if valid_mask is None:
            return torch.ones_like(reference)
        if not torch.is_tensor(valid_mask):
            raise TypeError("valid_mask必须是torch.Tensor。")

        mask = valid_mask.to(
            device=reference.device,
            dtype=reference.dtype,
        )
        if mask.ndim == 1:
            mask = mask.reshape(1, 1, -1)
        elif mask.ndim == 2:
            mask = mask.unsqueeze(1)

        if mask.shape[0] == 1 and reference.shape[0] > 1:
            mask = mask.expand(reference.shape[0], -1, -1)
        if mask.shape != reference.shape:
            raise ValueError(
                "valid_mask形状必须与光谱一致："
                f"掩码={tuple(mask.shape)}，光谱={tuple(reference.shape)}。"
            )
        if not torch.isfinite(mask).all():
            raise ValueError("valid_mask包含NaN或无穷值。")
        if not torch.logical_or(mask == 0.0, mask == 1.0).all():
            raise ValueError("valid_mask只能包含0和1。")
        if torch.any(mask.flatten(start_dim=1).sum(dim=1) <= 0.0):
            raise ValueError("每条光谱至少需要一个有效Raman点。")
        return mask

    def forward(
        self,
        img: torch.Tensor,
        *args,
        valid_mask: torch.Tensor | None = None,
        condition: torch.Tensor | None = None,
        **kwargs,
    ) -> torch.Tensor:
        batch_size, channels, sequence_length = img.shape
        if channels != self.channels or sequence_length != self.seq_length:
            raise ValueError(
                "输入光谱形状与扩散模型不一致："
                f"得到{tuple(img.shape)}，期望通道={self.channels}、"
                f"长度={self.seq_length}。"
            )

        mask = self._prepare_mask(valid_mask, img)
        prepared_condition = self._prepare_condition(
            condition,
            batch_size,
            img.device,
            img.dtype,
        )
        if self.diversity_enabled:
            if prepared_condition is None:
                raise RuntimeError("D4.3多样性约束要求提供condition。")
            _, inverse = torch.unique(
                prepared_condition,
                dim=0,
                sorted=True,
                return_inverse=True,
            )
            grouped_timestep = self._sample_training_timesteps(
                int(inverse.max().item()) + 1,
                img.device,
            )
            timestep = grouped_timestep[inverse]
        else:
            timestep = self._sample_training_timesteps(batch_size, img.device)
        normalized = self.normalize(img) * mask
        return self.p_losses(
            normalized,
            timestep,
            *args,
            valid_mask=mask,
            condition=prepared_condition,
            **kwargs,
        )

    def p_losses(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor | None = None,
        model_forward_kwargs: dict[str, Any] | None = None,
        return_reduced_loss: bool = True,
        loss_reduction: str = "mean",
        valid_mask: torch.Tensor | None = None,
        condition: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if model_forward_kwargs is None:
            model_forward_kwargs = {}
        if loss_reduction not in {"mean", "none"}:
            raise ValueError("loss_reduction只支持mean或none。")

        mask = self._prepare_mask(valid_mask, x_start)
        prepared_condition = self._prepare_condition(
            condition,
            x_start.shape[0],
            x_start.device,
            x_start.dtype,
        )
        x_start = x_start * mask
        if noise is None:
            noise = torch.randn_like(x_start)
        noise = noise * mask

        noisy_input = self.q_sample(
            x_start=x_start,
            t=t,
            noise=noise,
        ) * mask

        if self.self_condition and random() < 0.5:
            with torch.no_grad():
                self_condition = self.model_predictions(
                    noisy_input,
                    t,
                ).pred_x_start
                self_condition = self_condition.detach() * mask
            model_forward_kwargs = {
                **model_forward_kwargs,
                "self_cond": self_condition,
            }

        model_out = self.model(
            noisy_input,
            t,
            valid_mask=mask,
            condition=prepared_condition,
            **model_forward_kwargs,
        )

        if self.objective == "pred_noise":
            target = noise
        elif self.objective == "pred_x0":
            target = x_start
        elif self.objective == "pred_v":
            target = self.predict_v(x_start, t, noise)
        else:
            raise ValueError(f"未知扩散预测目标：{self.objective}")

        pointwise_loss = F.mse_loss(
            model_out,
            target,
            reduction="none",
        )
        weighted_pointwise = (
            pointwise_loss
            * mask
            * _extract(self.loss_weight, t, pointwise_loss.shape)
        )

        if not return_reduced_loss:
            return weighted_pointwise

        valid_count = mask.flatten(start_dim=1).sum(dim=1).clamp_min(1.0)
        per_sample = (
            weighted_pointwise.flatten(start_dim=1).sum(dim=1)
            / valid_count
        )
        if loss_reduction == "none":
            return per_sample
        ddpm_uniform_loss = per_sample.mean()
        timestep_fidelity_weight = self._high_noise_weights(t).to(
            device=per_sample.device,
            dtype=per_sample.dtype,
        )
        ddpm_loss = (
            (per_sample * timestep_fidelity_weight).sum()
            / timestep_fidelity_weight.sum().clamp_min(1.0e-12)
        )
        zero = torch.zeros_like(ddpm_loss)

        if self.diversity_enabled:
            if self.diversity_loss_module is None:
                raise RuntimeError(
                    "D4.3扩散模型尚未配置diversity_constraint_state。"
                )
            if prepared_condition is None:
                raise RuntimeError("D4.3多样性损失缺少condition。")
            diversity = self.diversity_loss_module(
                predicted_scaled_residual=model_out,
                target_scaled_residual=x_start,
                timesteps=t,
                alphas_cumprod=self.alphas_cumprod,
                valid_mask=mask,
                condition=prepared_condition,
            )
            uncapped_diversity = (
                self.diversity_total_weight
                * diversity["diversity_timestep_weighted_loss"]
            )
            diversity_cap = ddpm_loss.detach() * self.diversity_maximum_ratio
            diversity_scale = torch.clamp(
                diversity_cap
                / uncapped_diversity.detach().abs().clamp_min(1.0e-12),
                max=1.0,
            )
            weighted_diversity = uncapped_diversity * diversity_scale
        else:
            diversity = {}
            uncapped_diversity = zero
            weighted_diversity = zero

        if self.quality_fidelity_enabled:
            if prepared_condition is None:
                raise RuntimeError("D4.3.2保真约束缺少condition。")
            quality = self._quality_fidelity_losses(
                prediction=model_out,
                target=x_start,
                valid_mask=mask,
                condition=prepared_condition,
                timesteps=t,
            )
            uncapped_quality = (
                float(self.quality_fidelity_configuration["total_weight"])
                * quality["quality_fidelity_raw_loss"]
            )
            quality_cap = ddpm_loss.detach() * float(
                self.quality_fidelity_configuration[
                    "maximum_total_ratio_to_ddpm"
                ]
            )
            quality_scale = torch.clamp(
                quality_cap
                / uncapped_quality.detach().abs().clamp_min(1.0e-12),
                max=1.0,
            )
            weighted_quality = uncapped_quality * quality_scale
        else:
            quality = {}
            uncapped_quality = zero
            weighted_quality = zero

        reduced = ddpm_loss + weighted_diversity + weighted_quality
        timestep_fraction = t.to(dtype=torch.float32) / float(
            max(self.num_timesteps - 1, 1)
        )
        high_sampling = self.quality_fidelity_configuration.get(
            "high_noise_sampling", {}
        )
        high_threshold = float(
            high_sampling.get("minimum_timestep_fraction", 0.75)
        )
        self._latest_loss_components = {
            "total_loss": reduced.detach(),
            "ddpm_loss": ddpm_loss.detach(),
            "ddpm_uniform_loss": ddpm_uniform_loss.detach(),
            "mean_high_noise_weight": timestep_fidelity_weight.mean().detach(),
            "mean_training_timestep_fraction": timestep_fraction.mean().detach(),
            "high_noise_training_sample_fraction": (
                timestep_fraction >= high_threshold
            ).to(dtype=torch.float32).mean().detach(),
            "physics_loss": zero,
            "diversity_loss": weighted_diversity.detach(),
            "diversity_uncapped_loss": uncapped_diversity.detach(),
            "diversity_raw_loss": diversity.get(
                "diversity_raw_loss", zero
            ).detach(),
            "pairwise_distance_loss": diversity.get(
                "pairwise_distance_loss", zero
            ).detach(),
            "pairwise_correlation_loss": diversity.get(
                "pairwise_correlation_loss", zero
            ).detach(),
            "pointwise_variance_floor_loss": diversity.get(
                "pointwise_variance_floor_loss", zero
            ).detach(),
            "diversity_active_samples": diversity.get(
                "diversity_active_samples", zero
            ).detach(),
            "conditional_diversity_active_groups": diversity.get(
                "conditional_diversity_active_groups", zero
            ).detach(),
            "mean_diversity_timestep_weight": diversity.get(
                "mean_diversity_timestep_weight", zero
            ).detach(),
            "quality_fidelity_loss": weighted_quality.detach(),
            "quality_fidelity_uncapped_loss": uncapped_quality.detach(),
            "quality_fidelity_raw_loss": quality.get(
                "quality_fidelity_raw_loss", zero
            ).detach(),
            "first_derivative_fidelity_loss": quality.get(
                "first_derivative_fidelity_loss", zero
            ).detach(),
            "multiscale_shape_loss": quality.get(
                "multiscale_shape_loss", zero
            ).detach(),
            "condition_multiscale_variance_floor_loss": quality.get(
                "condition_multiscale_variance_floor_loss", zero
            ).detach(),
            "condition_derivative_variance_floor_loss": quality.get(
                "condition_derivative_variance_floor_loss", zero
            ).detach(),
            "condition_mean_fidelity_loss": quality.get(
                "condition_mean_fidelity_loss", zero
            ).detach(),
            "condition_envelope_loss": quality.get(
                "condition_envelope_loss", zero
            ).detach(),
            "quality_fidelity_active_groups": quality.get(
                "quality_fidelity_active_groups", zero
            ).detach(),
        }
        return reduced

    def model_predictions(
        self,
        x: torch.Tensor,
        t: torch.Tensor,
        x_self_cond: torch.Tensor | None = None,
        clip_x_start: bool = False,
        rederive_pred_noise: bool = False,
        model_forward_kwargs: dict[str, Any] | None = None,
        valid_mask: torch.Tensor | None = None,
        condition: torch.Tensor | None = None,
        **kwargs,
    ):
        if self._sampling_valid_mask is not None and valid_mask is not None:
            raise RuntimeError("采样内部掩码不能与显式valid_mask同时提供。")
        if self._sampling_condition is not None and condition is not None:
            raise RuntimeError("采样内部条件不能与显式condition同时提供。")

        mask = (
            self._sampling_valid_mask
            if self._sampling_valid_mask is not None
            else valid_mask
        )
        active_condition = (
            self._sampling_condition
            if self._sampling_condition is not None
            else condition
        )
        if mask is None and active_condition is None:
            return super().model_predictions(
                x,
                t,
                x_self_cond,
                clip_x_start,
                rederive_pred_noise,
            )

        prepared = self._prepare_mask(mask, x)
        prepared_condition = self._prepare_condition(
            active_condition,
            x.shape[0],
            x.device,
            x.dtype,
        )
        if x_self_cond is not None:
            x_self_cond = x_self_cond * prepared

        forward_kwargs = dict(model_forward_kwargs or {})
        forward_kwargs.update(kwargs)
        forward_kwargs.pop("self_cond", None)
        model_output = self.model(
            x * prepared,
            t,
            valid_mask=prepared,
            condition=prepared_condition,
            **forward_kwargs,
        )

        if self.objective == "pred_noise":
            pred_noise = model_output
            pred_x_start = self.predict_start_from_noise(
                x * prepared,
                t,
                pred_noise,
            )
            if clip_x_start:
                pred_x_start = pred_x_start.clamp(-1.0, 1.0)
            if clip_x_start and rederive_pred_noise:
                pred_noise = self.predict_noise_from_start(
                    x * prepared,
                    t,
                    pred_x_start,
                )
        elif self.objective == "pred_x0":
            pred_x_start = model_output
            if clip_x_start:
                pred_x_start = pred_x_start.clamp(-1.0, 1.0)
            pred_noise = self.predict_noise_from_start(
                x * prepared,
                t,
                pred_x_start,
            )
        elif self.objective == "pred_v":
            pred_x_start = self.predict_start_from_v(
                x * prepared,
                t,
                model_output,
            )
            if clip_x_start:
                pred_x_start = pred_x_start.clamp(-1.0, 1.0)
            pred_noise = self.predict_noise_from_start(
                x * prepared,
                t,
                pred_x_start,
            )
        else:
            raise ValueError(f"未知扩散预测目标：{self.objective}")

        return MaskedModelPrediction(
            pred_noise * prepared,
            pred_x_start * prepared,
        )

    @torch.no_grad()
    def sample(
        self,
        batch_size: int = 16,
        *args,
        valid_mask: torch.Tensor | None = None,
        condition: torch.Tensor | None = None,
        **kwargs,
    ):
        reference = torch.empty(
            (int(batch_size), self.channels, self.seq_length),
            device=self.betas.device,
        )
        mask = self._prepare_mask(valid_mask, reference)
        prepared_condition = self._prepare_condition(
            condition,
            int(batch_size),
            reference.device,
            reference.dtype,
        )

        if (
            self._sampling_valid_mask is not None
            or self._sampling_condition is not None
        ):
            raise RuntimeError("同一个扩散对象不能同时执行两次掩码采样。")

        self._sampling_valid_mask = mask
        self._sampling_condition = prepared_condition
        try:
            generated = super().sample(
                batch_size,
                *args,
                **kwargs,
            )
        finally:
            self._sampling_valid_mask = None
            self._sampling_condition = None

        if isinstance(generated, tuple):
            primary = generated[0] * mask
            return (primary, *generated[1:])
        return generated * mask
