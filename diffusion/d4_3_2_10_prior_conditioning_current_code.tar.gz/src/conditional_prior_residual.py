"""D4.2 condition-aware, mask-aware D2.6 prior residual bank.

There is one shared conditional DDPM.  This module only stores the small
train-only preprocessing/generation state for every chemical condition.
Each state is fitted on the valid Raman prefix of that condition, so a
600--2000 spectrum never contributes padded values to a 600--2500 prior.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np

from src.broad_local_residual import BroadLocalResidualDecomposer
from src.prior_residual import PriorResidualTransformer


STATE_VERSION = "d4.2_conditional_prior_residual_v1"


def _as_2d_finite(value: np.ndarray, name: str) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim != 2 or array.shape[0] == 0 or array.shape[1] < 2:
        raise ValueError(f"{name}必须是非空二维数组[N,L]。")
    if not np.isfinite(array).all():
        raise ValueError(f"{name}包含NaN或无穷值。")
    return array


def _valid_prefix_length(mask: np.ndarray) -> int:
    values = np.asarray(mask, dtype=np.float32).reshape(-1)
    if not np.logical_or(values == 0.0, values == 1.0).all():
        raise ValueError("valid_mask只能包含0和1。")
    length = int(values.sum())
    if length < 2:
        raise ValueError("每个条件至少需要两个有效Raman点。")
    expected = np.zeros_like(values)
    expected[:length] = 1.0
    if not np.array_equal(values, expected):
        raise ValueError("D4.2当前要求有效Raman区间是从轴起点开始的连续前缀。")
    return length


def _build_outer(configuration: dict[str, Any]) -> PriorResidualTransformer:
    low = configuration.get("low_frequency", {}) or {}
    blended = configuration.get("blended_frequency", {}) or {}
    return PriorResidualTransformer(
        prior_method=str(configuration.get("prior_method", "pca_reconstruction")),
        normalization_method=str(
            configuration.get("residual_normalization", "robust_asinh")
        ),
        target_abs_max=float(configuration.get("target_abs_max", 1.0)),
        residual_quantile=float(configuration.get("residual_quantile", 99.5)),
        pointwise_scale_floor_quantile=float(
            configuration.get("pointwise_scale_floor_quantile", 10.0)
        ),
        mad_scale_factor=float(configuration.get("mad_scale_factor", 1.4826)),
        epsilon=float(configuration.get("epsilon", 1.0e-8)),
        pca_explained_variance_ratio=float(
            configuration.get("pca_explained_variance_ratio", 0.95)
        ),
        pca_max_components=configuration.get("pca_max_components", 6),
        pca_sampling_strategy=str(
            configuration.get(
                "pca_sampling_strategy",
                "independent_truncated_gaussian_scores",
            )
        ),
        pca_score_clip_standard_deviations=float(
            configuration.get("pca_score_clip_standard_deviations", 2.5)
        ),
        low_frequency_method=str(low.get("method", "gaussian")),
        low_frequency_sigma_cm1=float(low.get("sigma_cm1", 40.0)),
        low_frequency_truncate=float(low.get("truncate", 4.0)),
        blended_peak_component_ratio=float(
            blended.get("peak_component_ratio", 0.5)
        ),
    )


@dataclass
class ConditionalPriorEntry:
    valid_length: int
    number_of_training_spectra: int
    outer: PriorResidualTransformer
    broad_local: BroadLocalResidualDecomposer


class ConditionalPriorResidualBank:
    """A dictionary of condition-specific D2.6 states, not 126 DDPMs."""

    def __init__(
        self,
        *,
        prior_configuration: dict[str, Any],
        broad_local_configuration: dict[str, Any],
    ) -> None:
        if not isinstance(prior_configuration, dict) or not bool(
            prior_configuration.get("enabled", False)
        ):
            raise ValueError("D4.2要求启用prior_residual。")
        if str(prior_configuration.get("prior_method", "")).strip().lower() != (
            "pca_reconstruction"
        ):
            raise ValueError("D4.2条件先验当前要求pca_reconstruction。")
        if not isinstance(broad_local_configuration, dict) or not bool(
            broad_local_configuration.get("enabled", False)
        ):
            raise ValueError("D4.2要求启用broad_local_residual。")
        self.prior_configuration = dict(prior_configuration)
        self.broad_local_configuration = dict(broad_local_configuration)
        self.model_axis: np.ndarray | None = None
        self.entries: dict[str, ConditionalPriorEntry] = {}

    @staticmethod
    def _condition_array(
        condition_ids: Sequence[str], number_of_spectra: int
    ) -> np.ndarray:
        if len(condition_ids) != number_of_spectra:
            raise ValueError("condition_ids数量必须与光谱数量一致。")
        values = np.asarray([str(value) for value in condition_ids], dtype=object)
        if any(not str(value).strip() for value in values):
            raise ValueError("condition_ids不能包含空值。")
        return values

    def fit(
        self,
        spectra: np.ndarray,
        *,
        valid_masks: np.ndarray,
        condition_ids: Sequence[str],
        training_indices: Sequence[int],
        raman_shift: np.ndarray,
    ) -> "ConditionalPriorResidualBank":
        values = _as_2d_finite(spectra, "spectra")
        masks = _as_2d_finite(valid_masks, "valid_masks")
        if masks.shape != values.shape:
            raise ValueError("valid_masks形状必须与spectra一致。")
        conditions = self._condition_array(condition_ids, values.shape[0])
        axis = np.asarray(raman_shift, dtype=np.float64).reshape(-1)
        if (
            axis.size != values.shape[1]
            or not np.isfinite(axis).all()
            or not np.all(np.diff(axis) > 0.0)
        ):
            raise ValueError("raman_shift必须与统一模型轴一致且严格递增。")
        train = np.asarray(training_indices, dtype=np.int64).reshape(-1)
        if train.size == 0 or np.any(train < 0) or np.any(train >= values.shape[0]):
            raise ValueError("training_indices为空或越界。")
        if np.unique(train).size != train.size:
            raise ValueError("training_indices不能重复。")

        self.model_axis = axis.copy()
        self.entries = {}
        all_conditions = sorted(set(str(value) for value in conditions))
        for condition_id in all_conditions:
            group_train = train[conditions[train] == condition_id]
            if group_train.size < 4:
                raise ValueError(
                    f"条件{condition_id}只有{group_train.size}条训练光谱；"
                    "D4.2 PCA+broad/local至少需要4条。"
                )
            lengths = {_valid_prefix_length(masks[index]) for index in group_train}
            if len(lengths) != 1:
                raise ValueError(f"条件{condition_id}的训练光谱Raman范围不一致。")
            valid_length = lengths.pop()
            training_values = values[group_train, :valid_length]
            condition_axis = axis[:valid_length]

            outer = _build_outer(self.prior_configuration)
            outer.fit(training_values, raman_shift=condition_axis)
            reference = outer.reference_priors_for_spectra(training_values)
            raw_residuals = (training_values - reference).astype(np.float32)
            broad_local = BroadLocalResidualDecomposer.from_configuration(
                self.broad_local_configuration
            )
            broad_local.fit(raw_residuals, raman_shift=condition_axis)
            self.entries[condition_id] = ConditionalPriorEntry(
                valid_length=valid_length,
                number_of_training_spectra=int(group_train.size),
                outer=outer,
                broad_local=broad_local,
            )
        return self

    def _entry(self, condition_id: str) -> ConditionalPriorEntry:
        key = str(condition_id)
        if key not in self.entries:
            raise KeyError(f"条件先验库中不存在{key!r}。")
        return self.entries[key]

    def transform(
        self,
        spectra: np.ndarray,
        *,
        valid_masks: np.ndarray,
        condition_ids: Sequence[str],
    ) -> np.ndarray:
        if self.model_axis is None or not self.entries:
            raise RuntimeError("条件先验库尚未拟合。")
        values = _as_2d_finite(spectra, "spectra")
        masks = _as_2d_finite(valid_masks, "valid_masks")
        if values.shape != masks.shape or values.shape[1] != self.model_axis.size:
            raise ValueError("待变换光谱、掩码与条件先验库轴不一致。")
        conditions = self._condition_array(condition_ids, values.shape[0])
        result = np.zeros_like(values, dtype=np.float32)
        for condition_id in sorted(set(str(value) for value in conditions)):
            entry = self._entry(condition_id)
            indices = np.flatnonzero(conditions == condition_id)
            for index in indices:
                if _valid_prefix_length(masks[index]) != entry.valid_length:
                    raise ValueError(
                        f"条件{condition_id}的光谱掩码与训练状态不一致。"
                    )
            active = values[indices, : entry.valid_length]
            reference = entry.outer.reference_priors_for_spectra(active)
            raw = (active - reference).astype(np.float32)
            result[indices, : entry.valid_length] = (
                entry.broad_local.transform_raw_residuals(raw)
            )
        return result

    def diagnostic_transform(
        self,
        spectrum: np.ndarray,
        *,
        valid_mask: np.ndarray,
        condition_id: str,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return the learned local domain and deterministic true-spectrum base.

        The D4.2/D4.3 DDPM learns only the scaled local residual.  A timestep
        recovery diagnostic must therefore corrupt that residual and restore a
        prediction with the same outer-PCA plus broad component extracted from
        the selected real spectrum.  Random generation priors are deliberately
        not used in a denoising-recovery test.
        """

        if self.model_axis is None or not self.entries:
            raise RuntimeError("条件先验库尚未拟合。")
        values = _as_2d_finite(spectrum, "spectrum")
        masks = _as_2d_finite(valid_mask, "valid_mask")
        if values.shape != masks.shape or values.shape[0] != 1:
            raise ValueError("诊断光谱和掩码必须为形状一致的[1,L]数组。")
        if values.shape[1] != self.model_axis.size:
            raise ValueError("诊断光谱长度与条件先验库模型轴不一致。")

        entry = self._entry(condition_id)
        if _valid_prefix_length(masks[0]) != entry.valid_length:
            raise ValueError(f"条件{condition_id}的诊断掩码与训练状态不一致。")
        active = values[:, : entry.valid_length]
        reference = entry.outer.reference_priors_for_spectra(active)
        raw = (active - reference).astype(np.float32)
        broad, _ = entry.broad_local.split_raw_residuals(raw)
        scaled_local = entry.broad_local.transform_raw_residuals(raw)

        model_domain = np.zeros_like(values, dtype=np.float32)
        deterministic_base = np.zeros_like(values, dtype=np.float32)
        model_domain[:, : entry.valid_length] = scaled_local
        deterministic_base[:, : entry.valid_length] = reference + broad
        return model_domain, deterministic_base

    def restore_diagnostic_prediction(
        self,
        scaled_local_residual: np.ndarray,
        *,
        deterministic_base: np.ndarray,
        condition_id: str,
    ) -> np.ndarray:
        """Restore a timestep prediction with its matching deterministic base."""

        values = _as_2d_finite(scaled_local_residual, "scaled_local_residual")
        base = _as_2d_finite(deterministic_base, "deterministic_base")
        if values.shape != base.shape:
            raise ValueError("scaled_local_residual与deterministic_base形状不一致。")
        entry = self._entry(condition_id)
        if values.shape[1] < entry.valid_length:
            raise ValueError("诊断预测长度小于条件有效Raman长度。")
        restored = np.zeros_like(values, dtype=np.float32)
        local = entry.broad_local.inverse_local_transform(
            values[:, : entry.valid_length]
        )
        restored[:, : entry.valid_length] = (
            base[:, : entry.valid_length] + local
        )
        return restored

    def reconstruct_generated(
        self,
        scaled_local_residuals: np.ndarray,
        *,
        condition_id: str,
        prior_random_generator: np.random.Generator,
        broad_random_generator: np.random.Generator,
    ) -> np.ndarray:
        values = _as_2d_finite(scaled_local_residuals, "scaled_local_residuals")
        entry = self._entry(condition_id)
        if values.shape[1] < entry.valid_length:
            raise ValueError("生成残差长度小于条件有效Raman长度。")
        local = entry.broad_local.inverse_local_transform(
            values[:, : entry.valid_length]
        )
        prior = entry.outer.sample_reference_priors(
            values.shape[0], random_generator=prior_random_generator
        )
        broad = entry.broad_local.sample_broad_residuals(
            values.shape[0], random_generator=broad_random_generator
        )
        reconstructed = prior + broad + local
        if not np.isfinite(reconstructed).all():
            raise RuntimeError("条件先验残差重建产生NaN或无穷值。")
        return reconstructed.astype(np.float32, copy=False)

    def valid_length(self, condition_id: str) -> int:
        return self._entry(condition_id).valid_length

    def apply_score_clip_runtime_override(
        self,
        standard_deviations: float | None,
    ) -> dict[str, Any]:
        """Override PCA sampling ranges in memory without changing checkpoint state.

        Both the outer spectrum prior and the broad-residual prior are sampled
        during D4.2/D4.3 reconstruction.  Keeping their truncation ranges equal
        avoids restoring the outer variability while silently leaving the broad
        component compressed.
        """

        checkpoint_outer_values = sorted(
            {
                float(entry.outer.pca_score_clip_standard_deviations)
                for entry in self.entries.values()
            }
        )
        checkpoint_broad_values = sorted(
            {
                float(entry.broad_local.broad_score_clip_standard_deviations)
                for entry in self.entries.values()
            }
        )
        information: dict[str, Any] = {
            "active": standard_deviations is not None,
            "checkpoint_outer_values": checkpoint_outer_values,
            "checkpoint_broad_values": checkpoint_broad_values,
            "runtime_value": None,
            "overridden": False,
        }
        if standard_deviations is None:
            return information

        value = float(standard_deviations)
        if not np.isfinite(value) or not 0.5 <= value <= 4.0:
            raise ValueError(
                "PCA score采样截断范围必须位于[0.5, 4.0]个标准差。"
            )
        for entry in self.entries.values():
            entry.outer.pca_score_clip_standard_deviations = value
            entry.broad_local.broad_score_clip_standard_deviations = value
        information["runtime_value"] = value
        information["overridden"] = bool(
            any(abs(item - value) > 1.0e-12 for item in checkpoint_outer_values)
            or any(abs(item - value) > 1.0e-12 for item in checkpoint_broad_values)
        )
        return information

    def state_dict(self) -> dict[str, Any]:
        if self.model_axis is None or not self.entries:
            raise RuntimeError("条件先验库尚未拟合。")
        return {
            "version": STATE_VERSION,
            "enabled": True,
            "model_axis": self.model_axis.tolist(),
            "number_of_conditions": len(self.entries),
            "conditions": {
                key: {
                    "valid_length": entry.valid_length,
                    "number_of_training_spectra": entry.number_of_training_spectra,
                    "prior_residual_state": entry.outer.state_dict(),
                    "broad_local_residual_state": entry.broad_local.state_dict(),
                }
                for key, entry in sorted(self.entries.items())
            },
        }

    @classmethod
    def from_state_dict(cls, state: dict[str, Any]) -> "ConditionalPriorResidualBank":
        if not isinstance(state, dict) or state.get("version") != STATE_VERSION:
            raise ValueError("不支持的conditional_prior_residual_state。")
        records = state.get("conditions")
        if not isinstance(records, dict) or not records:
            raise ValueError("条件先验状态不包含conditions。")
        instance = cls.__new__(cls)
        instance.prior_configuration = {}
        instance.broad_local_configuration = {}
        instance.model_axis = np.asarray(state.get("model_axis"), dtype=np.float64)
        if (
            instance.model_axis.ndim != 1
            or instance.model_axis.size < 2
            or not np.isfinite(instance.model_axis).all()
            or not np.all(np.diff(instance.model_axis) > 0.0)
        ):
            raise ValueError("条件先验状态中的model_axis无效。")
        instance.entries = {}
        for condition_id, record in records.items():
            if not isinstance(record, dict):
                raise ValueError(f"条件{condition_id}的状态无效。")
            valid_length = int(record.get("valid_length", 0))
            if not 2 <= valid_length <= instance.model_axis.size:
                raise ValueError(f"条件{condition_id}的valid_length无效。")
            instance.entries[str(condition_id)] = ConditionalPriorEntry(
                valid_length=valid_length,
                number_of_training_spectra=int(
                    record.get("number_of_training_spectra", 0)
                ),
                outer=PriorResidualTransformer.from_state_dict(
                    record["prior_residual_state"]
                ),
                broad_local=BroadLocalResidualDecomposer.from_state_dict(
                    record["broad_local_residual_state"]
                ),
            )
        if int(state.get("number_of_conditions", len(instance.entries))) != len(
            instance.entries
        ):
            raise ValueError("条件先验状态中的条件数量不一致。")
        return instance

    def summary(self) -> dict[str, Any]:
        lengths = [entry.valid_length for entry in self.entries.values()]
        counts = [entry.number_of_training_spectra for entry in self.entries.values()]
        return {
            "number_of_conditions": len(self.entries),
            "valid_lengths": {
                str(length): lengths.count(length) for length in sorted(set(lengths))
            },
            "training_spectra_per_condition": sorted(set(counts)),
            "total_training_spectra": int(sum(counts)),
        }
