"""
在第三方 GaussianDiffusion1D 基础上加入 D3 SERS 额外损失。

本文件只重写训练阶段的 ``p_losses``。采样、DDPM、DDIM、EMA 和
已有模型参数结构仍沿用 denoising-diffusion-pytorch==2.2.6。

D3.4新增：
1. 物理损失可以继续作为病态保护；
2. 多样性损失在prior_residual_scaled域约束样本间距离结构；
3. 两类损失都可通过YAML独立开启或关闭。
"""

from __future__ import annotations

from random import random
from typing import Any, Callable, TypeVar

import torch
from torch.nn import functional as F

from src.one_dimensional_ddpm import GaussianDiffusion1D
from src.sers_diversity_constraints import (
    DifferentiableSersDiversityLoss,
    normalize_diversity_configuration,
)
from src.sers_physics_constraints import (
    DifferentiableSersPhysicsLoss,
    normalize_physics_configuration,
)


T = TypeVar("T")


def _default(value: T | None, factory: Callable[[], T]) -> T:
    """兼容第三方库 default 辅助函数的本地实现。"""

    return value if value is not None else factory()


def _extract(
    values: torch.Tensor,
    timesteps: torch.Tensor,
    target_shape: torch.Size,
) -> torch.Tensor:
    """按 batch 时间步读取一维扩散缓冲区，并扩展到目标形状。"""

    gathered = values.gather(-1, timesteps)

    return gathered.reshape(
        timesteps.shape[0],
        *((1,) * (len(target_shape) - 1)),
    )


class SersPhysicsGuidedGaussianDiffusion1D(GaussianDiffusion1D):
    """D3物理病态保护 + D3.4残差多样性约束的一维 DDPM。"""

    def __init__(
        self,
        model,
        *,
        physics_configuration: dict[str, Any] | None = None,
        diversity_configuration: dict[str, Any] | None = None,
        **kwargs,
    ) -> None:
        super().__init__(model, **kwargs)

        self.physics_configuration = normalize_physics_configuration(
            physics_configuration or {"enabled": False}
        )
        self.diversity_configuration = normalize_diversity_configuration(
            diversity_configuration or {"enabled": False}
        )

        self.physics_enabled = bool(
            self.physics_configuration.get("enabled", False)
        )
        self.diversity_enabled = bool(
            self.diversity_configuration.get("enabled", False)
        )

        if not self.physics_enabled and not self.diversity_enabled:
            raise ValueError(
                "SersPhysicsGuidedGaussianDiffusion1D至少需要启用"
                "physics_constraints或diversity_constraints之一。"
            )

        if self.objective != "pred_x0":
            raise ValueError(
                "D3物理/多样性约束当前只支持"
                "diffusion.objective=pred_x0。"
            )

        self.physics_total_weight = (
            float(self.physics_configuration["total_weight"])
            if self.physics_enabled
            else 0.0
        )
        self.diversity_total_weight = (
            float(self.diversity_configuration["total_weight"])
            if self.diversity_enabled
            else 0.0
        )

        if self.physics_enabled and self.physics_total_weight <= 0.0:
            raise ValueError(
                "physics_constraints.total_weight必须大于0。"
            )

        if self.diversity_enabled and self.diversity_total_weight <= 0.0:
            raise ValueError(
                "diversity_constraints.total_weight必须大于0。"
            )

        self.physics_loss_module: (
            DifferentiableSersPhysicsLoss | None
        ) = None
        self.diversity_loss_module: (
            DifferentiableSersDiversityLoss | None
        ) = None

        # 只用于日志，不写入checkpoint metadata。
        self._latest_loss_components: dict[str, torch.Tensor] = {}

    def configure_physics_constraints(
        self,
        *,
        physics_constraint_state: dict[str, Any],
        prior_residual_state: dict[str, Any],
    ) -> None:
        """注入只使用训练集拟合的D2.1和D3物理状态。"""

        self.physics_loss_module = DifferentiableSersPhysicsLoss(
            physics_constraint_state=physics_constraint_state,
            prior_residual_state=prior_residual_state,
            padded_length=self.seq_length,
        )

    def configure_diversity_constraints(
        self,
        *,
        diversity_constraint_state: dict[str, Any],
    ) -> None:
        """注入只使用训练集拟合的D3.4多样性状态。"""

        self.diversity_loss_module = DifferentiableSersDiversityLoss(
            diversity_constraint_state=diversity_constraint_state,
            padded_length=self.seq_length,
        )

    def get_latest_loss_components(self) -> dict[str, torch.Tensor]:
        """返回最近一次前向传播的分项损失副本。"""

        return {
            name: value.detach()
            for name, value in self._latest_loss_components.items()
        }

    def p_losses(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor | None = None,
        model_forward_kwargs: dict[str, Any] | None = None,
        return_reduced_loss: bool = True,
    ):
        """计算原始 DDPM 损失、D3物理损失和D3.4多样性损失。"""

        if model_forward_kwargs is None:
            model_forward_kwargs = {}

        noise = _default(
            noise,
            lambda: torch.randn_like(x_start),
        )
        noisy_input = self.q_sample(
            x_start=x_start,
            t=t,
            noise=noise,
        )

        if self.self_condition and random() < 0.5:
            with torch.no_grad():
                self_condition = self.model_predictions(
                    noisy_input,
                    t,
                ).pred_x_start
                self_condition.detach_()

            model_forward_kwargs = {
                **model_forward_kwargs,
                "self_cond": self_condition,
            }

        model_out = self.model(
            noisy_input,
            t,
            **model_forward_kwargs,
        )

        if self.objective == "pred_noise":
            target = noise
        elif self.objective == "pred_x0":
            target = x_start
        elif self.objective == "pred_v":
            target = self.predict_v(x_start, t, noise)
        else:
            raise ValueError(f"未知扩散预测目标：{self.objective}")

        pointwise_ddpm_loss = F.mse_loss(
            model_out,
            target,
            reduction="none",
        )
        pointwise_loss_weight = _extract(
            self.loss_weight,
            t,
            pointwise_ddpm_loss.shape,
        )

        if not return_reduced_loss:
            return pointwise_ddpm_loss * pointwise_loss_weight

        ddpm_per_sample = pointwise_ddpm_loss.flatten(
            start_dim=1
        ).mean(dim=1)
        ddpm_per_sample = ddpm_per_sample * _extract(
            self.loss_weight,
            t,
            ddpm_per_sample.shape,
        )
        ddpm_loss = ddpm_per_sample.mean()

        zero = torch.zeros_like(ddpm_loss)

        if self.physics_enabled:
            if self.physics_loss_module is None:
                raise RuntimeError(
                    "D3物理扩散模型尚未配置physics_constraint_state。"
                    "训练入口必须在模型构建后调用"
                    "configure_physics_constraints。"
                )

            physics = self.physics_loss_module(
                predicted_scaled_residual=model_out,
                target_scaled_residual=x_start,
                timesteps=t,
                alphas_cumprod=self.alphas_cumprod,
            )
            weighted_physics_loss = (
                self.physics_total_weight
                * physics["physics_timestep_weighted_loss"]
            )
        else:
            physics = {}
            weighted_physics_loss = zero

        if self.diversity_enabled:
            if self.diversity_loss_module is None:
                raise RuntimeError(
                    "D3.4扩散模型尚未配置diversity_constraint_state。"
                    "训练入口必须在模型构建后调用"
                    "configure_diversity_constraints。"
                )

            diversity = self.diversity_loss_module(
                predicted_scaled_residual=model_out,
                target_scaled_residual=x_start,
                timesteps=t,
                alphas_cumprod=self.alphas_cumprod,
            )
            weighted_diversity_loss = (
                self.diversity_total_weight
                * diversity["diversity_timestep_weighted_loss"]
            )
        else:
            diversity = {}
            weighted_diversity_loss = zero

        total_loss = (
            ddpm_loss
            + weighted_physics_loss
            + weighted_diversity_loss
        )

        self._latest_loss_components = {
            "total_loss": total_loss,
            "ddpm_loss": ddpm_loss,
            "physics_loss": weighted_physics_loss,
            "physics_raw_loss": physics.get("physics_raw_loss", zero),
            "position_loss": physics.get("position_loss", zero),
            "width_loss": physics.get("width_loss", zero),
            "sharpness_loss": physics.get("sharpness_loss", zero),
            "presence_loss": physics.get("presence_loss", zero),
            "local_shape_loss": physics.get("local_shape_loss", zero),
            "roughness_loss": physics.get("roughness_loss", zero),
            "extreme_loss": physics.get("extreme_loss", zero),
            "negative_valley_loss": physics.get(
                "negative_valley_loss",
                zero,
            ),
            "scaled_residual_guard_loss": physics.get(
                "scaled_residual_guard_loss",
                zero,
            ),
            "mean_timestep_weight": physics.get(
                "mean_timestep_weight",
                zero,
            ),
            "mean_pathology_timestep_weight": physics.get(
                "mean_pathology_timestep_weight",
                zero,
            ),
            "mean_detected_peaks": physics.get(
                "mean_detected_peaks",
                zero,
            ),
            "diversity_loss": weighted_diversity_loss,
            "diversity_raw_loss": diversity.get(
                "diversity_raw_loss",
                zero,
            ),
            "pairwise_distance_loss": diversity.get(
                "pairwise_distance_loss",
                zero,
            ),
            "pairwise_correlation_loss": diversity.get(
                "pairwise_correlation_loss",
                zero,
            ),
            "pointwise_variance_floor_loss": diversity.get(
                "pointwise_variance_floor_loss",
                zero,
            ),
            "diversity_active_samples": diversity.get(
                "diversity_active_samples",
                zero,
            ),
            "mean_diversity_timestep_weight": diversity.get(
                "mean_diversity_timestep_weight",
                zero,
            ),
        }

        return total_loss