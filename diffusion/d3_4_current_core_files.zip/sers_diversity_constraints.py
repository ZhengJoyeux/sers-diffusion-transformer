"""
D3.4：低噪声先验残差域样本间多样性约束。

目的：
1. 不再强制生成谱复制某一条target峰形；
2. 不再用D3.3-B那种容易失效的batch标准差硬拉；
3. 在低噪声时间步，让预测残差之间的距离关系接近真实残差之间的距离关系；
4. 防止生成结果坍缩成同一条模板谱。

计算域：prior_residual_scaled，即D2.1的pointwise_mad_asinh残差域。
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


DIVERSITY_STATE_SCHEMA_VERSION = 1


def _finite_float(value: Any, field_name: str) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name}必须是数值。") from error

    if not np.isfinite(parsed):
        raise ValueError(f"{field_name}必须为有限数值。")

    return parsed


def _positive_float(value: Any, field_name: str) -> float:
    parsed = _finite_float(value, field_name)
    if parsed <= 0.0:
        raise ValueError(f"{field_name}必须大于0。")
    return parsed


def _nonnegative_float(value: Any, field_name: str) -> float:
    parsed = _finite_float(value, field_name)
    if parsed < 0.0:
        raise ValueError(f"{field_name}不能小于0。")
    return parsed


def _fraction(value: Any, field_name: str, *, allow_zero: bool = True) -> float:
    parsed = _finite_float(value, field_name)
    lower_ok = parsed >= 0.0 if allow_zero else parsed > 0.0
    if not lower_ok or parsed > 1.0:
        interval = "[0,1]" if allow_zero else "(0,1]"
        raise ValueError(f"{field_name}必须在{interval}范围内。")
    return parsed


def _positive_integer(value: Any, field_name: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name}必须是整数。") from error

    if parsed <= 0:
        raise ValueError(f"{field_name}必须大于0。")
    return parsed


def _percentile(value: Any, field_name: str) -> float:
    parsed = _finite_float(value, field_name)
    if not 0.0 <= parsed <= 100.0:
        raise ValueError(f"{field_name}必须在[0,100]范围内。")
    return parsed


def _section(configuration: dict[str, Any], name: str) -> dict[str, Any]:
    value = configuration.setdefault(name, {})
    if not isinstance(value, dict):
        raise TypeError(f"diversity_constraints.{name}必须是字典。")
    return value


def normalize_diversity_configuration(configuration: dict[str, Any]) -> dict[str, Any]:
    """校验并补全D3.4多样性配置。"""

    if configuration is None:
        configuration = {"enabled": False}

    if not isinstance(configuration, dict):
        raise TypeError("diversity_constraints必须是字典。")

    config = deepcopy(configuration)
    config["enabled"] = bool(config.get("enabled", False))

    if not config["enabled"]:
        return config

    strategy = str(
        config.get("strategy", "low_noise_pairwise_residual_geometry")
    ).strip().lower()

    if strategy != "low_noise_pairwise_residual_geometry":
        raise ValueError(
            "diversity_constraints.strategy必须为"
            "low_noise_pairwise_residual_geometry。"
        )

    config["strategy"] = strategy
    config["method_version"] = "d3_4_pairwise_residual_diversity"
    config["calculation_domain"] = "prior_residual_scaled"
    config["total_weight"] = _positive_float(
        config.get("total_weight", 0.01),
        "diversity_constraints.total_weight",
    )
    config["epsilon"] = _positive_float(
        config.get("epsilon", 1.0e-8),
        "diversity_constraints.epsilon",
    )

    gate = _section(config, "low_noise_gate")
    gate["minimum_alpha_cumprod"] = _fraction(
        gate.get("minimum_alpha_cumprod", 0.70),
        "diversity_constraints.low_noise_gate.minimum_alpha_cumprod",
        allow_zero=False,
    )
    gate["minimum_samples"] = _positive_integer(
        gate.get("minimum_samples", 4),
        "diversity_constraints.low_noise_gate.minimum_samples",
    )

    pairwise_distance = _section(config, "pairwise_distance")
    pairwise_distance["enabled"] = bool(pairwise_distance.get("enabled", True))
    pairwise_distance["metric"] = str(
        pairwise_distance.get("metric", "whitened_l2")
    ).strip().lower()
    if pairwise_distance["metric"] != "whitened_l2":
        raise ValueError("pairwise_distance.metric当前只支持whitened_l2。")

    pairwise_distance["minimum_distance_ratio"] = _fraction(
        pairwise_distance.get("minimum_distance_ratio", 0.45),
        "diversity_constraints.pairwise_distance.minimum_distance_ratio",
        allow_zero=False,
    )
    pairwise_distance["maximum_distance_ratio"] = _positive_float(
        pairwise_distance.get("maximum_distance_ratio", 1.80),
        "diversity_constraints.pairwise_distance.maximum_distance_ratio",
    )
    pairwise_distance["transition_fraction"] = _positive_float(
        pairwise_distance.get("transition_fraction", 0.20),
        "diversity_constraints.pairwise_distance.transition_fraction",
    )
    pairwise_distance["weight"] = _nonnegative_float(
        pairwise_distance.get("weight", 1.0),
        "diversity_constraints.pairwise_distance.weight",
    )

    if (
        pairwise_distance["maximum_distance_ratio"]
        <= pairwise_distance["minimum_distance_ratio"]
    ):
        raise ValueError(
            "pairwise_distance.maximum_distance_ratio必须大于"
            "minimum_distance_ratio。"
        )

    pairwise_correlation = _section(config, "pairwise_correlation")
    pairwise_correlation["enabled"] = bool(
        pairwise_correlation.get("enabled", True)
    )
    pairwise_correlation["maximum_excess_correlation"] = _fraction(
        pairwise_correlation.get("maximum_excess_correlation", 0.005),
        "diversity_constraints.pairwise_correlation."
        "maximum_excess_correlation",
    )
    pairwise_correlation["transition_fraction"] = _positive_float(
        pairwise_correlation.get("transition_fraction", 0.20),
        "diversity_constraints.pairwise_correlation.transition_fraction",
    )
    pairwise_correlation["weight"] = _nonnegative_float(
        pairwise_correlation.get("weight", 0.5),
        "diversity_constraints.pairwise_correlation.weight",
    )

    variance_floor = _section(config, "pointwise_variance_floor")
    variance_floor["enabled"] = bool(variance_floor.get("enabled", True))
    variance_floor["active_std_quantile"] = _percentile(
        variance_floor.get("active_std_quantile", 30.0),
        "diversity_constraints.pointwise_variance_floor.active_std_quantile",
    )
    variance_floor["minimum_std_ratio"] = _fraction(
        variance_floor.get("minimum_std_ratio", 0.30),
        "diversity_constraints.pointwise_variance_floor.minimum_std_ratio",
        allow_zero=False,
    )
    variance_floor["reference_std_floor_fraction"] = _fraction(
        variance_floor.get("reference_std_floor_fraction", 0.25),
        "diversity_constraints.pointwise_variance_floor."
        "reference_std_floor_fraction",
        allow_zero=False,
    )
    variance_floor["weight"] = _nonnegative_float(
        variance_floor.get("weight", 0.2),
        "diversity_constraints.pointwise_variance_floor.weight",
    )

    total_component_weight = (
        pairwise_distance["weight"]
        + pairwise_correlation["weight"]
        + variance_floor["weight"]
    )
    if total_component_weight <= 0.0:
        raise ValueError("D3.4至少需要一个多样性分项权重大于0。")

    return config


def fit_sers_diversity_constraint_state(
    *,
    training_scaled_residuals: np.ndarray,
    configuration: dict[str, Any],
) -> dict[str, Any]:
    """只用训练集拟合D3.4参考统计。"""

    config = normalize_diversity_configuration(configuration)

    if not bool(config.get("enabled", False)):
        return {
            "schema_version": DIVERSITY_STATE_SCHEMA_VERSION,
            "enabled": False,
            "configuration": config,
        }

    values = np.asarray(training_scaled_residuals, dtype=np.float32)

    if values.ndim != 2:
        raise ValueError("training_scaled_residuals必须是二维数组[N,L]。")
    if values.shape[0] < 2:
        raise ValueError("D3.4至少需要2条训练光谱。")
    if values.shape[1] < 4:
        raise ValueError("D3.4光谱长度至少需要4个点。")
    if not np.isfinite(values).all():
        raise ValueError("training_scaled_residuals包含NaN或无穷值。")

    epsilon = float(config["epsilon"])
    pointwise_std = np.std(values, axis=0, ddof=0).astype(np.float32)
    positive_std = pointwise_std[pointwise_std > epsilon]

    if positive_std.size == 0:
        raise ValueError(
            "训练集缩放残差逐点标准差几乎为零，"
            "D3.4无法拟合多样性参考状态。"
        )

    variance_floor = config["pointwise_variance_floor"]
    std_floor = float(
        np.median(positive_std)
        * variance_floor["reference_std_floor_fraction"]
    )
    std_floor = max(std_floor, epsilon)

    active_threshold = float(
        np.percentile(
            positive_std,
            variance_floor["active_std_quantile"],
        )
    )
    active_threshold = max(active_threshold, std_floor)
    active_mask = pointwise_std >= active_threshold

    if int(np.sum(active_mask)) < 4:
        active_mask = pointwise_std >= np.percentile(pointwise_std, 10.0)

    if int(np.sum(active_mask)) < 4:
        active_mask = np.ones_like(pointwise_std, dtype=bool)

    whitening_std = np.maximum(pointwise_std, std_floor).astype(np.float32)

    return {
        "schema_version": DIVERSITY_STATE_SCHEMA_VERSION,
        "enabled": True,
        "strategy": "low_noise_pairwise_residual_geometry",
        "method_version": "d3_4_pairwise_residual_diversity",
        "configuration": config,
        "number_of_training_spectra": int(values.shape[0]),
        "original_length": int(values.shape[1]),
        "pointwise_std": pointwise_std.tolist(),
        "whitening_std": whitening_std.tolist(),
        "active_mask": active_mask.astype(np.float32).tolist(),
        "std_floor": float(std_floor),
        "active_std_threshold": float(active_threshold),
        "active_point_count": int(np.sum(active_mask)),
    }


class DifferentiableSersDiversityLoss(nn.Module):
    """低噪声batch内pairwise几何多样性损失。"""

    def __init__(
        self,
        *,
        diversity_constraint_state: dict[str, Any],
        padded_length: int,
    ) -> None:
        super().__init__()
        self._load_state(
            diversity_constraint_state=diversity_constraint_state,
            padded_length=padded_length,
        )
        self._load_config_values()

    def _load_state(
        self,
        *,
        diversity_constraint_state: dict[str, Any],
        padded_length: int,
    ) -> None:
        if not isinstance(diversity_constraint_state, dict):
            raise TypeError("diversity_constraint_state必须是字典。")

        if int(diversity_constraint_state.get("schema_version", 0)) != (
            DIVERSITY_STATE_SCHEMA_VERSION
        ):
            raise ValueError("diversity_constraint_state版本不受支持。")

        if not bool(diversity_constraint_state.get("enabled", False)):
            raise ValueError("diversity_constraint_state没有启用。")

        self.configuration = normalize_diversity_configuration(
            diversity_constraint_state["configuration"]
        )
        self.original_length = int(diversity_constraint_state["original_length"])
        self.padded_length = int(padded_length)

        if self.padded_length < self.original_length:
            raise ValueError("padded_length不能小于original_length。")

        pointwise_std = torch.as_tensor(
            diversity_constraint_state["pointwise_std"],
            dtype=torch.float32,
        ).reshape(-1)
        whitening_std = torch.as_tensor(
            diversity_constraint_state["whitening_std"],
            dtype=torch.float32,
        ).reshape(-1)
        active_mask = torch.as_tensor(
            diversity_constraint_state["active_mask"],
            dtype=torch.float32,
        ).reshape(-1)

        if (
            pointwise_std.numel() != self.original_length
            or whitening_std.numel() != self.original_length
            or active_mask.numel() != self.original_length
        ):
            raise ValueError("D3.4状态长度与original_length不一致。")

        self.register_buffer("pointwise_std", pointwise_std)
        self.register_buffer("whitening_std", whitening_std)
        self.register_buffer("active_mask", active_mask)

    def _load_config_values(self) -> None:
        config = self.configuration
        self.epsilon = float(config["epsilon"])

        gate = config["low_noise_gate"]
        self.minimum_alpha_cumprod = float(gate["minimum_alpha_cumprod"])
        self.minimum_samples = int(gate["minimum_samples"])

        distance = config["pairwise_distance"]
        self.distance_enabled = bool(distance["enabled"])
        self.minimum_distance_ratio = float(distance["minimum_distance_ratio"])
        self.maximum_distance_ratio = float(distance["maximum_distance_ratio"])
        self.distance_transition_fraction = float(distance["transition_fraction"])
        self.distance_weight = float(distance["weight"])

        correlation = config["pairwise_correlation"]
        self.correlation_enabled = bool(correlation["enabled"])
        self.maximum_excess_correlation = float(
            correlation["maximum_excess_correlation"]
        )
        self.correlation_transition_fraction = float(
            correlation["transition_fraction"]
        )
        self.correlation_weight = float(correlation["weight"])

        variance = config["pointwise_variance_floor"]
        self.variance_enabled = bool(variance["enabled"])
        self.minimum_std_ratio = float(variance["minimum_std_ratio"])
        self.variance_weight = float(variance["weight"])

        self.component_weight_sum = (
            self.distance_weight
            + self.correlation_weight
            + self.variance_weight
        )

    def _zero_result(self, device: torch.device, dtype: torch.dtype) -> dict[str, torch.Tensor]:
        zero = torch.zeros((), device=device, dtype=dtype)
        return {
            "diversity_raw_loss": zero,
            "diversity_timestep_weighted_loss": zero,
            "pairwise_distance_loss": zero,
            "pairwise_correlation_loss": zero,
            "pointwise_variance_floor_loss": zero,
            "diversity_active_samples": zero,
            "mean_diversity_timestep_weight": zero,
        }

    def _select_low_noise(
        self,
        values: torch.Tensor,
        timesteps: torch.Tensor,
        alphas_cumprod: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        alpha = alphas_cumprod.gather(0, timesteps).to(values.dtype)
        mask = alpha >= self.minimum_alpha_cumprod
        return values[mask], alpha[mask]

    def _active_crop(self, values: torch.Tensor) -> torch.Tensor:
        cropped = values[..., : self.original_length]
        active = self.active_mask.to(device=values.device, dtype=values.dtype)
        return cropped * active.view(1, 1, -1)

    def _pairwise_whitened_distance(self, values: torch.Tensor) -> torch.Tensor:
        whitening = self.whitening_std.to(
            device=values.device,
            dtype=values.dtype,
        ).view(1, 1, -1)
        active = self.active_mask.to(
            device=values.device,
            dtype=values.dtype,
        ).view(1, 1, -1)

        whitened = values[..., : self.original_length] / whitening
        whitened = whitened * active
        denominator = active.sum().clamp_min(1.0)

        diff = whitened[:, None, :, :] - whitened[None, :, :, :]
        squared = torch.square(diff).sum(dim=(2, 3)) / denominator
        return torch.sqrt(squared + self.epsilon)

    def _pairwise_correlation(self, values: torch.Tensor) -> torch.Tensor:
        active = self.active_mask.to(
            device=values.device,
            dtype=values.dtype,
        ).view(1, 1, -1)

        selected = values[..., : self.original_length] * active
        denominator = active.sum().clamp_min(1.0)
        mean = selected.sum(dim=-1, keepdim=True) / denominator
        centered = (selected - mean) * active
        norm = torch.sqrt(torch.square(centered).sum(dim=-1) + self.epsilon)
        normalized = centered / norm[..., None]
        return torch.matmul(
            normalized.squeeze(1),
            normalized.squeeze(1).transpose(0, 1),
        )

    def _off_diagonal(self, matrix: torch.Tensor) -> torch.Tensor:
        count = matrix.shape[0]
        mask = ~torch.eye(count, device=matrix.device, dtype=torch.bool)
        return matrix[mask]

    def _distance_loss(
        self,
        predicted: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        predicted_distance = self._off_diagonal(
            self._pairwise_whitened_distance(predicted)
        )
        target_distance = self._off_diagonal(
            self._pairwise_whitened_distance(target)
        ).detach()

        lower = target_distance * self.minimum_distance_ratio
        upper = target_distance * self.maximum_distance_ratio
        transition = (
            target_distance * self.distance_transition_fraction
        ).clamp_min(self.epsilon)

        too_close = torch.square(
            F.relu(lower - predicted_distance) / transition
        )
        too_far = torch.square(
            F.relu(predicted_distance - upper) / transition
        )
        return (too_close + too_far).mean()

    def _correlation_loss(
        self,
        predicted: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        predicted_corr = self._off_diagonal(
            self._pairwise_correlation(predicted)
        )
        target_corr = self._off_diagonal(
            self._pairwise_correlation(target)
        ).detach()

        allowed = target_corr + self.maximum_excess_correlation
        transition = (
            (1.0 - target_corr).clamp_min(self.epsilon)
            * self.correlation_transition_fraction
        ).clamp_min(self.epsilon)

        return torch.square(
            F.relu(predicted_corr - allowed) / transition
        ).mean()

    def _variance_floor_loss(self, predicted: torch.Tensor) -> torch.Tensor:
        cropped = predicted[..., : self.original_length].squeeze(1)
        if cropped.shape[0] < 2:
            return torch.zeros((), device=predicted.device, dtype=predicted.dtype)

        predicted_std = torch.std(cropped, dim=0, unbiased=False)
        reference = self.pointwise_std.to(
            device=predicted.device,
            dtype=predicted.dtype,
        )
        active = self.active_mask.to(
            device=predicted.device,
            dtype=predicted.dtype,
        )

        required = reference * self.minimum_std_ratio
        transition = required.clamp_min(self.epsilon)
        loss = torch.square(F.relu(required - predicted_std) / transition)
        return (loss * active).sum() / active.sum().clamp_min(1.0)

    def forward(
        self,
        *,
        predicted_scaled_residual: torch.Tensor,
        target_scaled_residual: torch.Tensor,
        timesteps: torch.Tensor,
        alphas_cumprod: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        if predicted_scaled_residual.shape != target_scaled_residual.shape:
            raise ValueError("预测残差和目标残差形状必须一致。")
        if predicted_scaled_residual.ndim != 3:
            raise ValueError("残差张量必须为[B,1,L]。")

        predicted, selected_alpha = self._select_low_noise(
            predicted_scaled_residual,
            timesteps,
            alphas_cumprod,
        )
        target, _ = self._select_low_noise(
            target_scaled_residual,
            timesteps,
            alphas_cumprod,
        )

        if predicted.shape[0] < self.minimum_samples:
            return self._zero_result(
                predicted_scaled_residual.device,
                predicted_scaled_residual.dtype,
            )

        distance_loss = (
            self._distance_loss(predicted, target)
            if self.distance_enabled and self.distance_weight > 0.0
            else torch.zeros((), device=predicted.device, dtype=predicted.dtype)
        )
        correlation_loss = (
            self._correlation_loss(predicted, target)
            if self.correlation_enabled and self.correlation_weight > 0.0
            else torch.zeros((), device=predicted.device, dtype=predicted.dtype)
        )
        variance_loss = (
            self._variance_floor_loss(predicted)
            if self.variance_enabled and self.variance_weight > 0.0
            else torch.zeros((), device=predicted.device, dtype=predicted.dtype)
        )

        raw_loss = (
            self.distance_weight * distance_loss
            + self.correlation_weight * correlation_loss
            + self.variance_weight * variance_loss
        ) / max(self.component_weight_sum, self.epsilon)

        timestep_weight = torch.sqrt(selected_alpha.clamp_min(0.0)).mean()
        weighted_loss = raw_loss * timestep_weight

        return {
            "diversity_raw_loss": raw_loss,
            "diversity_timestep_weighted_loss": weighted_loss,
            "pairwise_distance_loss": distance_loss,
            "pairwise_correlation_loss": correlation_loss,
            "pointwise_variance_floor_loss": variance_loss,
            "diversity_active_samples": torch.as_tensor(
                float(predicted.shape[0]),
                device=predicted.device,
                dtype=predicted.dtype,
            ),
            "mean_diversity_timestep_weight": timestep_weight,
        }